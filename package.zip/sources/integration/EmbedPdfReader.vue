﻿<template>
  <div v-if="props.source && !pdfLoadError" ref="rootRef" class="embed-pdf-reader">
    <div ref="viewerHostRef" class="embed-pdf-reader__host"></div>
    <div v-if="pdfPreparing" class="embed-pdf-reader__loading embed-pdf-reader__loading--overlay">{{ pdfPreparing }}</div>
  </div>
  <div v-else class="embed-pdf-reader__loading">{{ pdfLoadError || props.i18n?.loading || 'Loading...' }}</div>
</template>

<script setup lang="ts">
import { computed, createApp, nextTick, onBeforeUnmount, ref, shallowRef, watch } from 'vue'
import { Dialog, showMessage } from 'siyuan'
import { bookshelfManager } from '@/core/bookshelf'
import { cloneStorageValue, createLatestSaver, deleteEmbedPdfAnnotation, readEmbedPdfAnnotations, readEmbedPdfProgress, trackPending, upsertEmbedPdfAnnotation, writeManagedFile, writeEmbedPdfProgress } from '@/core/storage'
import { diagnosticLog } from '@/core/diagnostics'
import { alignLegacyPdfAnnotations, needsLegacyPdfTextAlign } from '@/core/dataMigration'
import { createTooltip, showTooltip } from '@/core/MarkManager'
import { copyMark } from '@/utils/copy'
import { buildEmbedPdfTheme, embedPdfThemePreference } from '@/utils/embedPdfTheme'
import { addMissingPdfMenuItemsAfterFirst, capturePdfAnnotationImage, createEmbedPdfDocumentSource, ensureEmbedPdfStampManifests, ensureEmbedPdfWasmUrl, filterPdfSelectionColumns, getPdfSelectionMark, initEmbedPdfViewer, pdfAnnotationNote, pdfAnnotationText, pdfAnnotationWithReplies, pdfMarkFromAnnotation, pdfSelectionFromAnnotation, restorePdfAnnotationTool, sendPdfMarkToDoc, snapshotPdfAnnotationEvent, taskToPromise, writeBlobToClipboard } from '@/utils/embedPdfActions'
import { getPdfScrollStrategy, settingsManager, type ReaderSettings, type ReadTheme } from '@/composables/useSetting'
import { isMobile } from '@/utils/mobile'
import Translate from './Translate.vue'
import { createPdfReflowSession, replacePdfDocument, synchronizeReflowAnnotation } from '@/services/pdfReflow'
import type { ReflowDocument } from '@/core/pdfReflow'
import { pdfQuickSendCommandId } from '@/utils/keyboard'
import { embedPdfLocale } from '@/utils/embedPdfLocale'
import { pdfSpeakCommand } from '@/fork/tts/pdfSpeakCommand' // CUSTOM: fork

type EmbedPdfContainer = any
type PluginRegistry = any
type PdfAssets = { wasmUrl: string; stampManifests: any[] }
type PdfCommandDefinition = { id: string; label: string; icon?: string; categories?: string[]; action: (context?: any) => void | Promise<void>; active?: (context?: any) => boolean; visible?: (context?: any) => boolean; disabled?: (context?: any) => boolean }
const props = defineProps<{ source: File | string | null; settings?: ReaderSettings; theme?: string; customTheme?: ReadTheme; bookUrl?: string; storageKey?: string; hideAnnotations?: boolean; i18n?: any; onAnnotationPersisted?: (event: any) => void }>()
// dataId is derived from the file fingerprint and is stable across devices.
// The book URL is only a legacy alias because local paths differ after sync.
const sourceStorageKey = () => props.storageKey || props.bookUrl || ''
const storageKey = () => reflowOpen.value && reflowDocument ? reflowDocument.url : sourceStorageKey()
const pdfBookUrl = () => reflowOpen.value && reflowDocument ? reflowDocument.url : props.bookUrl || ''
const emit = defineEmits<{ ready: [registry: PluginRegistry, context: { documentId: string; bookUrl: string; storageKey: string }]; 'annotations-ready': [] }>()
const documentSource = shallowRef<any>(null)
const pdfAssets = shallowRef<PdfAssets | null>(null)
const pdfLoadError = ref('')
const pdfPreparing = ref('')
const rootRef = ref<HTMLElement | null>(null)
const viewerHostRef = ref<HTMLElement | null>(null)
const documentId = 'sireader-document'
const pdfLoadFailedMessage = () => props.i18n?.loadFailed || 'PDF load failed'
const pdfLoadingText = () => props.i18n?.loading || 'Loading...'
const failPdfLoad = (error: any) => {
  pdfPreparing.value = ''
  pdfLoadError.value = error?.message || pdfLoadFailedMessage()
}
const preparePdfAssets = async () => {
  if (pdfAssets.value) return pdfAssets.value
  const [wasmUrl, stampManifests] = await Promise.all([
    ensureEmbedPdfWasmUrl(),
    ensureEmbedPdfStampManifests().catch(() => []),
  ])
  return (pdfAssets.value = { wasmUrl, stampManifests })
}
let activeRegistry: PluginRegistry | null = null
let activeContainer: EmbedPdfContainer | null = null
let activeAnnotationScope: any = null
let annotationPersistenceQueue: Promise<void> = Promise.resolve()
let annotationCommitQueue: Promise<void> = Promise.resolve()
let savePendingAnnotations: (() => void) | null = null
let activeScrollScope: any = null
let pdfTooltip: HTMLElement | null = null
let pdfTooltipAnnotations: any[] = []
let currentPdfTooltipId = ''
let pdfTooltipFrame = 0
let nativePdfAnnotationIds = new Set<string>()
let cleanupDocumentEvents: (() => void) | null = null
let cleanupAnnotationEvents: (() => void) | null = null
let cleanupScrollEvents: (() => void) | null = null
let cleanupZoomEvents: (() => void) | null = null
let cleanupCaptureEvents: (() => void) | null = null
let cleanupTooltipEvents: (() => void) | null = null
let cleanupMigrationEvents: (() => void) | null = null
let cleanupPdfDoubleTapZoom: (() => void) | null = null
let pdfZoomRestore: any = null
let activeViewer: any = null
let pdfCommandIds: string[] = []
let viewerToken = 0
let copyNextCapture = false
let lastCaptureBlob: Blob | null = null
let zoomSaveTimer: any = null
let pdfAnnotationToolLocked = false
let lastPdfAnnotationToolId = ''
let cleanupPdfShortcutGuard: (() => void) | null = null
const reflowOpen = ref(false), reflowBusy = ref(false)
let reflowSession: ReturnType<typeof createPdfReflowSession> | null = null
let reflowController: AbortController | null = null
let reflowSwitching = false
let reflowDocument: (ReflowDocument & { url: string; name: string; original: { buffer: ArrayBuffer; name: string }; sourcePageCount: number; projectionIds: Set<string>; annotationsBridged: boolean }) | null = null
const togglePdfReflow = async () => {
  if (reflowBusy.value) { if (!reflowSwitching) reflowController?.abort(); return }
  const registry = activeRegistry
  if (!registry) return
  const documents = getCapability<any>(registry, 'document-manager')
  const current = documents?.getDocument(documentId)
  if (!current) return
  const controller = reflowController = new AbortController(), token = viewerToken
  const wasReflow = reflowOpen.value
  const currentPage = Math.max(0, (activeScrollScope?.getCurrentPage?.() || 1) - 1)
  reflowBusy.value = true
  pdfPreparing.value = (props.i18n?.pdfReflow || 'Text reflow') + '…'
  try {
    await flushAnnotations()
    controller.signal.throwIfAborted()
    const previous = { buffer: await taskToPromise<ArrayBuffer>(registry.getEngine().saveAsCopy(current)), name: current.name || documentSource.value?.name || 'document.pdf' }
    controller.signal.throwIfAborted()
    if (!reflowDocument) {
      const session = reflowSession = createPdfReflowSession(registry, documentId, taskToPromise, props.i18n)
      const width = Math.max(240, Math.min(720, rootRef.value?.clientWidth || 480))
      const result = await session.generate(previous.buffer, { width, height: Math.max(400, Math.min(960, rootRef.value?.clientHeight || 720)), fontSize: Math.max(12, Math.min(32, props.settings?.textSettings.fontSize || 18)) }, controller.signal, (page, count) => { if (token === viewerToken) pdfPreparing.value = (props.i18n?.pdfReflow || 'Text reflow') + ' ' + page + ' / ' + count })
      controller.signal.throwIfAborted()
      const digest = Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', result.buffer))).map(v => v.toString(16).padStart(2, '0')).join('')
      const name = 'reflow-' + digest + '.pdf', url = '/public/siyuan-sireader/reflow/' + name
      await writeManagedFile(new Blob([result.buffer], { type: 'application/pdf' }), url, name)
      controller.signal.throwIfAborted()
      if (token !== viewerToken) return
      reflowDocument = { ...result, url, name, original: previous, sourcePageCount: current.pages.length, projectionIds: new Set(), annotationsBridged: false }
      session.dispose(); if (reflowSession === session) reflowSession = null
    }
    controller.signal.throwIfAborted()
    if (token !== viewerToken) return
    if (!wasReflow) reflowDocument.original = previous
    const next = wasReflow ? reflowDocument.original : reflowDocument
    const targetPage = wasReflow ? (reflowDocument.pageMap[currentPage] ?? 0) : Math.max(0, reflowDocument.pageMap.indexOf(currentPage))
    ;[cleanupDocumentEvents, cleanupAnnotationEvents, cleanupScrollEvents, cleanupZoomEvents, cleanupCaptureEvents, cleanupTooltipEvents, cleanupPdfDoubleTapZoom].forEach(cleanup => cleanup?.())
    cleanupDocumentEvents = cleanupAnnotationEvents = cleanupScrollEvents = cleanupZoomEvents = cleanupCaptureEvents = cleanupTooltipEvents = cleanupPdfDoubleTapZoom = null
    reflowSwitching = true
    const switchToken = ++viewerToken
    try {
      await replacePdfDocument(documents, documentId, next, previous, taskToPromise, getCapability<any>(registry, 'annotation'))
      if (switchToken !== viewerToken || controller.signal.aborted) return
      reflowOpen.value = !wasReflow
    } finally { if (switchToken === viewerToken && !controller.signal.aborted) await handleReady(registry, true) }
    // A replacement can retain the zoom gate until a level is requested for its new page sizes.
    getCapability<any>(registry, 'zoom')?.forDocument(documentId)?.requestZoom?.(pdfZoomLevel() ?? 'fit-width')
    activeScrollScope?.scrollToPage?.({ pageNumber: targetPage + 1, behavior: 'instant' })
  } catch (error: any) { if (reflowController === controller && error?.name !== 'AbortError') showMessage(error?.message || props.i18n?.pdfReflowFailed, 3000, 'error') }
  finally { if (reflowController === controller) { reflowSession?.dispose(); reflowSession = null; reflowController = null; reflowSwitching = false; reflowBusy.value = false; pdfPreparing.value = '' } }
}
const disposePdfViewer = () => {
  reflowController?.abort(); reflowController = null; reflowSwitching = false
  reflowSession?.dispose(); reflowSession = null; reflowDocument = null
  reflowOpen.value = false; reflowBusy.value = false
  cleanupPdfShortcutGuard?.()
  cleanupPdfShortcutGuard = null
  savePendingAnnotations?.()
  savePendingAnnotations = null
  viewerToken++
  pdfAnnotationToolLocked = false
  lastPdfAnnotationToolId = ''
  activeViewer?.remove?.()
  activeViewer = null
  viewerHostRef.value?.replaceChildren()
}

const PDF_PAGE_THEME_STYLE = `
  :host([data-sireader-page-mode="dark"]) div[style*="mix-blend-mode"][style*="background-color"]{mix-blend-mode:screen!important}
  :host([data-sireader-page-mode="dark"]) img[src^="blob:"]{filter:invert(1) hue-rotate(180deg) brightness(.92) contrast(.92)}
  :host([data-sireader-hide-annotations]) :is([data-no-interaction],input[type="file"] ~ *){display:none!important}
  div[style*="background: rgb(0, 0, 0)"][style*="cursor: pointer"]:hover,
  div[style*="background: #000000"][style*="cursor: pointer"]:hover{opacity:.08!important}
`
const installPdfShortcutGuard = () => {
  // EmbedPDF handles shortcuts on document, including when a SiYuan table has focus.
  const onKeydown = (event: KeyboardEvent) => {
    if (!(event.ctrlKey || event.metaKey) || event.key.toLowerCase() !== 'c') return
    const target = event.composedPath()[0]
    if (target instanceof Element && !rootRef.value?.contains(target) && target.closest('table,[data-type="NodeTableCell"]')) event.stopImmediatePropagation()
  }
  document.addEventListener('keydown', onKeydown, true)
  return () => document.removeEventListener('keydown', onKeydown, true)
}
const pdfIcon = (id: string) => `<svg viewBox="0 0 24 24" style="width:16px;height:16px">${document.getElementById(id)?.innerHTML || ''}</svg>`
const PDF_BOTTOM_ICONS = { toc: 'lucide-menu', notes: 'lucide-notebook-pen', show: 'lucide-eye', hide: 'lucide-eye-off', close: 'lucide-x' }
const getCapability = <T = any>(registry: PluginRegistry, pluginId: string): T | null =>
  (registry.getPlugin(pluginId) as any)?.provides?.() || null
const disposePdfCommands = (commands: any) => { for (const id of pdfCommandIds) { try { commands?.unregisterCommand?.(id) } catch {} }; pdfCommandIds = [] }
const installPdfCommands = (commands: any, definitions: PdfCommandDefinition[], onError: (error: unknown) => void) => {
  disposePdfCommands(commands)
  if (!commands?.registerCommand || !commands?.resolve) return []
  const installed: PdfCommandDefinition[] = []
  for (const definition of definitions) try {
    commands.registerCommand({ ...definition, action: (context: any) => Promise.resolve().then(() => definition.action(context)).catch(onError), visible: definition.visible ? (context: any) => { try { return definition.visible!(context) } catch (error) { onError(error); return false } } : undefined, disabled: definition.disabled ? (context: any) => { try { return definition.disabled!(context) } catch (error) { onError(error); return true } } : undefined })
    commands.resolve(definition.id); installed.push(definition); pdfCommandIds.push(definition.id)
  } catch (error) { onError(error); try { commands.unregisterCommand?.(definition.id) } catch {} }
  return installed
}
const pdfShadowRoot = () => rootRef.value?.querySelector('embedpdf-container')?.shadowRoot || null
const pdfTheme = () => buildEmbedPdfTheme(props.theme, rootRef.value || undefined, props.customTheme)
const pdfThemePreference = () => embedPdfThemePreference(props.theme, rootRef.value || undefined, props.customTheme)
const normalizePdfZoomLevel = (value: unknown) => value === 'automatic' || value === 'fit-page' || value === 'fit-width' || (typeof value === 'number' && Number.isFinite(value) && value > 0) ? value : undefined
const pdfZoomLevel = () => normalizePdfZoomLevel(props.settings?.pdfZoomLevel)
const pdfInitialZoomLevel = () => { const value = pdfZoomLevel(); return typeof value === 'number' ? undefined : value }
const pdfPageBehavior = () => readerSettings()?.pageAnimation === 'push' ? 'instant' : 'smooth'
const setupPdfNavigation = (registry: PluginRegistry) => {
  // 2.15.1 native outline/comment navigation hardcodes smooth scrolling.
  const scroll = registry.getPlugin('scroll') as any
  const scrollToPage = scroll.scrollToPage.bind(scroll)
  scroll.scrollToPage = (options: any, documentId?: string) => scrollToPage({ ...options, behavior: options.behavior === 'instant' ? 'instant' : pdfPageBehavior() }, documentId)
}
const readerSettings = () => ((window as any).__sireader_settings || props.settings) as ReaderSettings | undefined
const ensurePageThemeStyle = () => {
  const shadow = (activeContainer as any)?.shadowRoot as ShadowRoot | undefined
  if (!shadow || shadow.querySelector('style[data-sireader-page-theme]')) return
  const style = document.createElement('style')
  style.setAttribute('data-sireader-page-theme', '')
  style.textContent = PDF_PAGE_THEME_STYLE
  shadow.appendChild(style)
}
const syncPdfAnnotationsHidden = (hidden: boolean) => {
  ;(activeContainer as any)?.toggleAttribute?.('data-sireader-hide-annotations', hidden)
  if (hidden) hidePdfTooltip()
}
const applyPdfTheme = () => {
  activeContainer?.setTheme(pdfTheme())
  activeContainer?.setAttribute('data-sireader-page-mode', pdfThemePreference())
  const image = props.settings?.backgroundImage || ''
  if (rootRef.value) Object.assign(rootRef.value.style, { backgroundImage: image ? `url("${image}")` : '', backgroundSize: image ? 'cover' : '', backgroundPosition: image ? 'center' : '' })
  syncPdfAnnotationsHidden(!!props.hideAnnotations)
  ensurePageThemeStyle()
}
const escapeHtml = (text = '') => String(text).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
const ensurePdfTooltip = () => {
  if (pdfTooltip) return pdfTooltip
  pdfTooltip = document.createElement('div')
  pdfTooltip.setAttribute('data-pdf-note-tooltip', 'true')
  pdfTooltip.style.cssText = 'position:fixed;display:none;width:340px;background:var(--b3-theme-surface);border:1px solid var(--b3-border-color);border-radius:12px;box-shadow:0 8px 24px rgba(0,0,0,.12),0 4px 8px rgba(0,0,0,.08);z-index:99999;pointer-events:none;overflow:hidden;transition:transform .12s,opacity .12s'
  document.body.appendChild(pdfTooltip)
  return pdfTooltip
}
const hidePdfTooltip = () => {
  if (!pdfTooltip) return
  currentPdfTooltipId = ''
  pdfTooltip.style.opacity = '0'
  pdfTooltip.style.transform = 'translateY(-8px)'
  pdfTooltip.style.display = 'none'
}
const showPdfTooltip = (item: any, x: number, y: number) => {
  const tip = ensurePdfTooltip()
  const note = pdfAnnotationNote(item)
  if (currentPdfTooltipId !== item.annotation.id) {
    currentPdfTooltipId = item.annotation.id
    const text = pdfAnnotationText(item)
    const quote = text ? `<div style="padding:8px 14px;background:var(--b3-theme-background-light);border-bottom:1px solid var(--b3-border-color);font-size:12px;color:var(--b3-theme-on-surface-variant);font-style:italic;line-height:1.5">${escapeHtml(text)}</div>` : ''
    tip.innerHTML = createTooltip({ icon: '#iconEdit', iconColor: 'var(--b3-theme-primary)', title: props.i18n?.note || 'Note', content: `${quote}<div style="padding:14px;font-size:13px;line-height:1.7;max-height:300px;overflow-y:auto;word-break:break-word;white-space:pre-wrap">${escapeHtml(note)}</div>` })
  }
  showTooltip(tip, x + 12, y + 12)
}
const pdfShadowElementFromPoint = (x: number, y: number) =>
  pdfShadowRoot()?.elementFromPoint(x, y) as HTMLElement | null
const pdfPointerElement = (x: number, y: number) => {
  let el = pdfShadowElementFromPoint(x, y)
  for (; el; el = el.parentElement) if (getComputedStyle(el).cursor === 'pointer') return el
  return null
}
const pdfViewportElement = (x: number, y: number) => {
  let el = pdfShadowElementFromPoint(x, y)
  for (; el; el = el.parentElement) {
    if (el.scrollHeight > el.clientHeight + 2 || el.scrollWidth > el.clientWidth + 2) return el
  }
  return null
}
const pdfAnnotationFromPoint = (x: number, y: number) => {
  const pointer = pdfPointerElement(x, y)
  const viewport = pointer && pdfViewportElement(x, y)
  if (!viewport || !activeScrollScope?.getRectPositionForPage) return null
  const box = viewport.getBoundingClientRect()
  const style = getComputedStyle(viewport)
  const offsetX = box.left + (Number.parseFloat(style.paddingLeft) || 0) - viewport.scrollLeft
  const offsetY = box.top + (Number.parseFloat(style.paddingTop) || 0) - viewport.scrollTop
  const target = pointer.getBoundingClientRect()
  let best: { item: any; overlap: number } | null = null
  for (const annotation of pdfTooltipAnnotations) {
    const item = pdfAnnotationWithReplies(annotation, pdfTooltipAnnotations)
    if (!pdfAnnotationNote(item)) continue
    for (const rect of (annotation.segmentRects?.length ? annotation.segmentRects : [annotation.rect]).filter(Boolean)) {
      const pos = activeScrollScope.getRectPositionForPage(annotation.pageIndex, rect)
      if (!pos) continue
      const left = offsetX + pos.origin.x
      const top = offsetY + pos.origin.y
      const overlap = Math.max(0, Math.min(left + pos.size.width, target.right) - Math.max(left, target.left))
        * Math.max(0, Math.min(top + pos.size.height, target.bottom) - Math.max(top, target.top))
      if (overlap && (!best || overlap > best.overlap)) best = { item, overlap }
    }
  }
  return best?.item || null
}
const refreshPdfTooltipAnnotations = () => {
  const all = activeAnnotationScope?.getAnnotations?.()?.map((item: any) => item.object).filter(Boolean) || []
  const replyParents = new Set(all.map((item: any) => item?.inReplyToId).filter(Boolean))
  pdfTooltipAnnotations = all.filter((item: any) => item?.contents || item?.custom?.note || item?.inReplyToId || replyParents.has(item?.id))
}
const selectedPdfAnnotation = () => activeAnnotationScope?.getSelectedAnnotation?.()?.object
const selectedPdfText = (annotation = selectedPdfAnnotation()) => annotation ? pdfSelectionFromAnnotation(annotation).text : ''
const pdfMarkWithImage = async (registry: PluginRegistry, annotation: any) => ({ ...pdfMarkFromAnnotation(annotation, pdfTooltipAnnotations), image: await capturePdfAnnotationImage(getCapability<any>(registry, 'render')?.forDocument(documentId), annotation) })
const quickDocs = () => ((props.settings ? props.settings.quickSendDocs : (window as any).__sireader_settings?.quickSendDocs) || []).filter((doc: any) => doc?.id).slice(0, 5)
const sendPdfMark = async (mark: any, docId: string) => {
  await sendPdfMarkToDoc(mark, docId, {
    bookUrl: pdfBookUrl(),
    settings: props.settings,
    marks: { updateMark: updateSelectedPdfBlockId },
    showMsg: (msg: string, type?: string) => showMessage(msg, 1500, type as any),
    i18n: props.i18n,
  })
}
const createPdfHoleFromSelection = async (registry: PluginRegistry) => {
  const selection = getCapability<any>(registry, 'selection')?.forDocument(documentId)
  const formatted = selection?.getFormattedSelection?.() || []
  for (const item of formatted) {
    if (!item?.rect || !item.segmentRects?.length) continue
    activeAnnotationScope?.createAnnotation?.(item.pageIndex, {
      id: `hole-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      type: 9,
      pageIndex: item.pageIndex,
      rect: item.rect,
      segmentRects: item.segmentRects,
      color: '#000000',
      strokeColor: '#000000',
      opacity: 1,
      blendMode: 0,
    })
  }
  selection?.clear?.()
  refreshPdfTooltipAnnotations()
}
const createPdfTranslationAnnotation = async (registry: PluginRegistry, text: string, translation: string) => {
  const selection = getCapability<any>(registry, 'selection')?.forDocument(documentId)
  try {
    const formatted = filterPdfSelectionColumns(selection?.getFormattedSelection?.() || [])
    const parentId = `translation-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`
    for (const item of formatted) {
      if (!item?.rect || !item.segmentRects?.length) continue
      const itemParentId = `${parentId}-${item.pageIndex}`
      activeAnnotationScope?.createAnnotation?.(item.pageIndex, {
        id: itemParentId,
        type: 9,
        pageIndex: item.pageIndex,
        rect: item.rect,
        segmentRects: item.segmentRects,
        color: '#FFCD45',
        strokeColor: '#FFCD45',
        opacity: 1,
        blendMode: 1,
        custom: { type: 'translation', text },
      })
      activeAnnotationScope?.createAnnotation?.(item.pageIndex, {
        id: `${itemParentId}-reply`,
        type: 0,
        pageIndex: item.pageIndex,
        rect: { origin: { x: item.rect.origin.x, y: item.rect.origin.y }, size: { width: 24, height: 24 } },
        contents: translation,
        inReplyToId: itemParentId,
        replyType: 1,
        custom: { type: 'translation-reply' },
      })
    }
    selection?.clear?.()
    refreshPdfTooltipAnnotations()
    showMessage(props.i18n?.annotationAdded || props.i18n?.saved || '已添加翻译批注', 1200)
  } catch (error: any) {
    showMessage(error?.message || props.i18n?.translationFailed || 'Translation failed', 2000, 'error')
  }
}
const updateSelectedPdfBlockId = async (item: any, updates: any) => {
  const annotation = item?.annotation || selectedPdfAnnotation()
  if (!annotation || !activeAnnotationScope?.updateAnnotation) return
  const custom = { ...(annotation.custom || {}), ...(typeof updates === 'string' ? { blockId: updates } : updates) }
  await activeAnnotationScope.updateAnnotation(annotation.pageIndex, annotation.id, { custom })
}
const queueCaptureCopyButton = () => {
  const shadow = pdfShadowRoot()
  if (!shadow) return
  const add = () => {
    if (shadow.querySelector('[data-sireader-copy-capture]')) return true
    const buttons = Array.from(shadow.querySelectorAll('button')) as HTMLButtonElement[]
    const download = buttons.find(button => /download/i.test(button.textContent || ''))
    const footer = download?.parentElement
    if (!download || !footer) return false
    const copy = download.cloneNode(true) as HTMLButtonElement
    copy.dataset.sireaderCopyCapture = 'true'
    copy.textContent = props.i18n?.copy || 'Copy'
    copy.onclick = event => {
      event.preventDefault()
      event.stopPropagation()
      lastCaptureBlob && void copyCaptureBlob(lastCaptureBlob).catch((error: any) => showMessage(error?.message || props.i18n?.copyFailed || 'Copy failed', 2000, 'error'))
    }
    footer.insertBefore(copy, download)
    return true
  }
  if (add()) return
  const observer = new MutationObserver(() => add() && observer.disconnect())
  observer.observe(shadow, { childList: true, subtree: true })
  setTimeout(() => observer.disconnect(), 3000)
}
const setupPdfBottomButtons = (registry: PluginRegistry) => {
  const shadow = pdfShadowRoot()
  if (!shadow) return
  let toolbarHidden = false
  const labelToolbar = () => toolbarHidden ? (props.i18n?.showTopToolbar || 'Show top toolbar') : (props.i18n?.hideTopToolbar || 'Hide top toolbar')
  const paint = (button: HTMLButtonElement, label: string, icon: string) => {
    button.title = button.ariaLabel = label
    button.innerHTML = pdfIcon(icon)
  }
  const add = () => {
    const bar = shadow.querySelector('[data-overlay-id="page-controls"] .pointer-events-auto > div') as HTMLElement | null
    const base = bar?.querySelector('button:last-of-type') as HTMLButtonElement | null
    if (!bar || !base) return false
    const mk = (key: string, label: string, icon: string, click: (button: HTMLButtonElement) => void) => {
      if (shadow.querySelector(`[data-${key}]`)) return true
      const button = base.cloneNode(false) as HTMLButtonElement
      button.setAttribute(`data-${key}`, 'true')
      button.type = 'button'
      button.disabled = false
      paint(button, label, icon)
      button.onclick = event => { event.preventDefault(); event.stopPropagation(); click(button) }
      bar.appendChild(button)
      return true
    }
    const toggleToolbar = (button: HTMLButtonElement) => {
      const ui = getCapability<any>(registry, 'ui')?.forDocument(documentId)
      toolbarHidden ? ui?.setActiveToolbar?.('top', 'main', 'main-toolbar') : ui?.closeToolbarSlot?.('top', 'main')
      toolbarHidden = !toolbarHidden
      paint(button, labelToolbar(), toolbarHidden ? PDF_BOTTOM_ICONS.show : PDF_BOTTOM_ICONS.hide)
    }
    return (
      mk('sireader-pdf-toc', props.i18n?.toc || props.i18n?.sidebarToc || 'Table of Contents', PDF_BOTTOM_ICONS.toc, () => window.dispatchEvent(new Event('sireader:togglePdfToc'))) &&
      mk('sireader-pdf-notes', props.i18n?.quickNotes || 'Notebook', PDF_BOTTOM_ICONS.notes, () => window.dispatchEvent(new Event('sireader:open-quick-notes'))) &&
      mk('sireader-pdf-toolbar', labelToolbar(), PDF_BOTTOM_ICONS.hide, toggleToolbar) &&
      (!isMobile() || mk('sireader-pdf-close', props.i18n?.close || 'Close', PDF_BOTTOM_ICONS.close, () => window.dispatchEvent(new CustomEvent('reader:mobile-close'))))
    )
  }
  if (add()) return
  const observer = new MutationObserver(() => add() && observer.disconnect())
  observer.observe(shadow, { childList: true, subtree: true })
  setTimeout(() => observer.disconnect(), 3000)
}
const setupPdfDoubleTapZoom = (registry: PluginRegistry) => {
  if (!isMobile()) return
  const zoom = getCapability<any>(registry, 'zoom')?.forDocument(documentId)
  const scroll = getCapability<any>(registry, 'scroll')?.forDocument(documentId)
  const viewport = getCapability<any>(registry, 'viewport')?.forDocument?.(documentId)
  const documents = getCapability<any>(registry, 'document-manager')
  const shadow = pdfShadowRoot()
  if (!shadow || !zoom || !scroll) return
  let last = { t: 0, x: 0, y: 0 }
  const zoomAt = (clientX: number, clientY: number) => {
    const vp = viewport?.getMetrics?.()
    const box = rootRef.value?.getBoundingClientRect()
    const x = clientX - (vp?.relativePosition?.x ?? box?.left ?? 0)
    const y = clientY - (vp?.relativePosition?.y ?? box?.top ?? 0)
    const hit = scroll.getMetrics(vp).pageVisibilityMetrics.find((m: any) => x >= m.viewportX && x <= m.viewportX + m.scaled.visibleWidth && y >= m.viewportY && y <= m.viewportY + m.scaled.visibleHeight)
    if (!hit) return
    if (pdfZoomRestore) {
      zoom.requestZoom?.(pdfZoomRestore, { vx: (vp?.clientWidth || box?.width || innerWidth) / 2, vy: (vp?.clientHeight || box?.height || innerHeight) / 2 })
      pdfZoomRestore = null
      return
    }
    const page = documents?.getDocumentState(documentId)?.document?.pages?.[hit.pageNumber - 1]
    if (!page?.size) return
    pdfZoomRestore = zoom.getState?.().zoomLevel
    const half = page.size.width > page.size.height
    zoom.zoomToArea(hit.pageNumber - 1, {
      origin: {
        x: half && x > hit.viewportX + hit.scaled.visibleWidth / 2 ? page.size.width / 2 : 0,
        y: 0,
      },
      size: {
        width: half ? page.size.width / 2 : page.size.width,
        height: page.size.height,
      },
    })
  }
  const onPointerUp = (event: PointerEvent) => {
    if (event.isPrimary === false) return
    const now = performance.now()
    const dx = event.clientX - last.x
    const dy = event.clientY - last.y
    if (now - last.t > 300 || dx * dx + dy * dy > 324) {
      last = { t: now, x: event.clientX, y: event.clientY }
      return
    }
    last.t = 0
    event.preventDefault()
    event.stopPropagation()
    zoomAt(event.clientX, event.clientY)
  }
  shadow.addEventListener('pointerup', onPointerUp, true)
  cleanupPdfDoubleTapZoom = () => shadow.removeEventListener('pointerup', onPointerUp, true)
}
const copyCaptureBlob = async (blob: Blob) => {
  await writeBlobToClipboard(blob)
  showMessage(props.i18n?.copied || 'Copied', 1200)
}
const openPdfTranslate = (text: string, onAddToAnnotation?: (translation: string) => void | Promise<void>) => {
  text = text.trim()
  if (!text) return showMessage(props.i18n?.noContent || 'No content', 1200)
  let app: any
  const dialog = new Dialog({
    title: props.i18n?.translate || 'Translate',
    content: '<div class="b3-dialog__content sireader-pdf-translate" style="padding:16px"></div>',
    width: '520px',
    destroyCallback: () => app?.unmount(),
  })
  app = createApp(Translate, { text, onAddToAnnotation, i18n: props.i18n })
  app.mount(dialog.element.querySelector('.sireader-pdf-translate') as HTMLElement)
}
const setupPdfCommands = (registry: PluginRegistry) => {
  const rawCommands = getCapability<any>(registry, 'commands')
  const ui = getCapability<any>(registry, 'ui')
  if (!rawCommands?.registerCommand || !rawCommands?.resolve || !ui?.getSchema || !ui?.mergeSchema) return
  const clearStalePdfSchema = () => {
    const schema = ui.getSchema?.()
    if (!schema) return
    const isSireader = (item: any) => String(item?.commandId || '').startsWith('sireader:') || String(item?.id || '').startsWith('sireader-')
    const cleanItems = (items: any[] = []): any[] => items.filter(item => !isSireader(item)).map(item => item.items ? { ...item, items: cleanItems(item.items) } : item)
    const selectionMenus = Object.fromEntries(Object.entries(schema.selectionMenus || {}).map(([key, menu]: any) => [key, { ...menu, items: (menu.items || []).filter((item: any) => !isSireader(item)) }]))
    const menus = Object.fromEntries(Object.entries(schema.menus || {}).map(([key, menu]: any) => [key, { ...menu, items: (menu.items || []).filter((item: any) => !isSireader(item)) }]))
    const toolbars = Object.fromEntries(Object.entries(schema.toolbars || {}).map(([key, toolbar]: any) => [key, { ...toolbar, items: cleanItems(toolbar.items) }]))
    ui.mergeSchema?.({ selectionMenus, menus, toolbars })
  }
  clearStalePdfSchema()
  disposePdfCommands(rawCommands)
  const definitions: PdfCommandDefinition[] = []
  const commands = { registerCommand: (definition: PdfCommandDefinition) => definitions.push(definition) }
  const uiDoc = ui?.forDocument(documentId)
  const selection = getCapability<any>(registry, 'selection')?.forDocument(documentId)
  const capture = getCapability<any>(registry, 'capture')?.forDocument(documentId)
  commands.registerCommand({ id: 'sireader:pdf-reflow', label: props.i18n?.pdfReflow || 'Text reflow', icon: 'book', categories: ['document'], action: togglePdfReflow, active: () => reflowOpen.value })
  const docs = quickDocs()
  const selectedMark = () => getPdfSelectionMark(selection)
  const openSendMenu = (type: 'selection' | 'annotation') => {
    const commandId = `sireader:send-${type}-menu`
    uiDoc?.openMenu?.(`sireader-pdf-send-${type}`, commandId, commandId)
  }
  commands?.registerCommand?.({
    id: 'sireader:lock-annotation-tool',
    label: props.i18n?.pdfKeepTool || 'Keep the selected tool active after drawing',
    icon: 'lock',
    categories: ['tools'],
    action: () => {
      pdfAnnotationToolLocked = !pdfAnnotationToolLocked
    },
    active: () => pdfAnnotationToolLocked,
  })
  commands?.registerCommand?.({
    id: 'sireader:copy-annotation-link',
    label: props.i18n?.copyBacklink || 'Copy Backlink',
    icon: 'copy',
    categories: ['annotation', 'sireader-copy-link'],
    action: async () => {
      const selected = selectedPdfAnnotation()
      if (!selected) return
      const mark = await pdfMarkWithImage(registry, selected)
      await copyMark(mark, { bookUrl: pdfBookUrl(), settings: props.settings, isPdf: true, showMsg: (msg: string, type?: string) => showMessage(msg, 1500, type as any) })
    },
    visible: () => !!selectedPdfAnnotation(),
  })
  commands?.registerCommand?.({
    id: 'sireader:dict-annotation',
    label: props.i18n?.dict || 'Dictionary',
    icon: 'book',
    categories: ['annotation', 'sireader'],
    action: async () => {
      const selected = selectedPdfAnnotation()
      if (!selected) return
      const selection = pdfSelectionFromAnnotation(selected)
      if (selection.text) (await import('@/utils/dictionary')).openDict(selection.text, innerWidth / 2, innerHeight / 2, selection)
    },
    visible: () => !!selectedPdfAnnotation(),
    disabled: () => !selectedPdfText(),
  })
  commands?.registerCommand?.({
    id: 'sireader:translate-annotation',
    label: props.i18n?.translate || 'Translate',
    icon: 'text',
    categories: ['annotation', 'sireader'],
    action: () => openPdfTranslate(selectedPdfText()),
    visible: () => !!selectedPdfAnnotation(),
    disabled: () => !selectedPdfText(),
  })
  commands?.registerCommand?.({
    id: 'sireader:send-selection-menu',
    label: props.i18n?.sendTo || 'Send to',
    icon: 'fileImport',
    categories: ['selection', 'sireader-send'],
    action: () => openSendMenu('selection'),
  })
  commands?.registerCommand?.({
    id: 'sireader:create-hole',
    label: props.i18n?.redaction || 'Redaction',
    icon: 'square',
    action: () => void createPdfHoleFromSelection(registry),
  })
  ;[
    ['dict', props.i18n?.dict || 'Dictionary', 'book', async (mark: any) => (await import('@/utils/dictionary')).openDict(mark.text, innerWidth / 2, innerHeight / 2, mark)],
    ['translate', props.i18n?.translate || 'Translate', 'text', (mark: any) => openPdfTranslate(mark.text, translation => createPdfTranslationAnnotation(registry, mark.text, translation))],
    pdfSpeakCommand(props), // CUSTOM: fork
  ].forEach(([id, label, icon, run]: any) => commands?.registerCommand?.({ id: `sireader:${id}-selection`, label, icon, action: async () => { const mark = await selectedMark(); if (mark?.text) run(mark) } }))
  docs.forEach((doc: any) => commands?.registerCommand?.({
    id: pdfQuickSendCommandId('selection', doc.id),
    label: doc.name || props.i18n?.sendTo || 'Send to',
    icon: 'fileImport',
    categories: ['selection', 'sireader-send'],
    action: async () => {
      const mark = await selectedMark()
      if (mark) await sendPdfMark(mark, doc.id)
      selection?.clear?.()
      uiDoc?.closeMenu?.('sireader-pdf-send-selection')
    },
  }))
  commands?.registerCommand?.({
    id: 'sireader:send-annotation-menu',
    label: props.i18n?.sendTo || 'Send to',
    icon: 'fileImport',
    categories: ['annotation', 'sireader-send'],
    action: () => openSendMenu('annotation'),
  })
  docs.forEach((doc: any) => commands?.registerCommand?.({
    id: pdfQuickSendCommandId('annotation', doc.id),
    label: doc.name || props.i18n?.sendTo || 'Send to',
    icon: 'fileImport',
    categories: ['annotation', 'sireader-send'],
    action: async () => {
      const selected = selectedPdfAnnotation()
      if (selected) {
        const mark = await pdfMarkWithImage(registry, selected)
        await sendPdfMark(mark, doc.id)
      }
      uiDoc?.closeMenu?.('sireader-pdf-send-annotation')
    },
  }))
  commands?.registerCommand?.({
    id: 'sireader:capture-copy',
    label: props.i18n?.copyScreenshot || props.i18n?.copy || 'Copy Screenshot',
    icon: 'copy',
    categories: ['document', 'document-capture', 'sireader-capture-copy'],
    action: () => {
      copyNextCapture = true
      window.dispatchEvent(new Event('sireader:close-reader-panels'))
      capture?.toggleMarqueeCapture?.()
    showMessage(props.i18n?.capture || 'Drag to select a screenshot area', 1500)
    },
  })
  const installed = installPdfCommands(rawCommands, definitions, (error: any) => showMessage(error?.message || props.i18n?.pdfOperationFailed || 'PDF operation failed', 2500, 'error'))
  const schema = ui?.getSchema?.()
  const annotationMenu = schema?.selectionMenus?.annotation
  const selectionMenu = schema?.selectionMenus?.selection
  const documentMenu = schema?.menus?.document
  const toolbars = { ...schema?.toolbars }
  const mainToolbar = toolbars['main-toolbar']
  const mainGroup = mainToolbar?.items?.find((item: any) => item.id === 'center-group')
  if (mainToolbar && mainGroup && !mainGroup.items.some((item: any) => item.id === 'sireader-lock-annotation-tool')) {
    const panIndex = mainGroup.items.findIndex((item: any) => item.id === 'pan-button')
    const lockIndex = panIndex > 0 && mainGroup.items[panIndex - 1]?.type === 'divider' ? panIndex - 1 : panIndex
    toolbars['main-toolbar'] = { ...mainToolbar, items: mainToolbar.items.map((item: any) => item.id === 'center-group' ? { ...item, items: [
      ...item.items.slice(0, lockIndex),
      { type: 'command-button', id: 'sireader-pdf-reflow', commandId: 'sireader:pdf-reflow', variant: 'icon', categories: ['tools'] },
      { type: 'command-button', id: 'sireader-lock-annotation-tool', commandId: 'sireader:lock-annotation-tool', variant: 'icon', categories: ['tools'] },
      ...item.items.slice(lockIndex),
    ] } : item) }
  }
  if (!annotationMenu && !selectionMenu && !documentMenu) return ui.mergeSchema?.({ toolbars })
  const requiredIds = ['sireader:pdf-reflow', 'sireader:lock-annotation-tool', 'sireader:copy-annotation-link', 'sireader:dict-annotation', 'sireader:translate-annotation', 'sireader:create-hole', 'sireader:dict-selection', 'sireader:translate-selection', 'sireader:speak-selection', 'sireader:capture-copy', ...docs.flatMap((doc: any) => [pdfQuickSendCommandId('selection', doc.id), pdfQuickSendCommandId('annotation', doc.id)])] // CUSTOM: speak-selection
  if (requiredIds.some(id => !installed.some(command => command.id === id))) return disposePdfCommands(rawCommands)
  if (annotationMenu) {
    const items = annotationMenu.items.filter((item: any) => !['sireader-send-annotation-list', 'sireader-send-annotation-divider', 'sireader-send-annotation-menu'].includes(item.id))
    annotationMenu.items = addMissingPdfMenuItemsAfterFirst(items, [
      { type: 'command-button', id: 'sireader-copy-annotation-link', commandId: 'sireader:copy-annotation-link', variant: 'icon', categories: ['annotation', 'sireader-copy-link'] },
      { type: 'command-button', id: 'sireader-dict-annotation', commandId: 'sireader:dict-annotation', variant: 'icon', categories: ['annotation', 'sireader'] },
      { type: 'command-button', id: 'sireader-translate-annotation', commandId: 'sireader:translate-annotation', variant: 'icon', categories: ['annotation', 'sireader'] },
      ...(docs.length ? [
        { type: 'divider', id: 'sireader-send-annotation-divider', categories: ['annotation', 'sireader-send'] },
        { type: 'command-button', id: 'sireader-send-annotation-menu', commandId: 'sireader:send-annotation-menu', variant: 'icon-text', categories: ['annotation', 'sireader-send'] },
      ] : []),
    ] as any)
  }
  if (selectionMenu) {
    const items = selectionMenu.items.filter((item: any) => !['sireader-create-mask', 'sireader-create-hole', 'sireader-dict-selection', 'sireader-translate-selection', 'sireader-speak-selection', 'sireader-send-selection-list', 'sireader-send-selection-divider', 'sireader-send-selection-menu'].includes(item.id))
    selectionMenu.items = addMissingPdfMenuItemsAfterFirst(items, [
      { type: 'command-button', id: 'sireader-create-hole', commandId: 'sireader:create-hole', variant: 'icon-text' },
      { type: 'command-button', id: 'sireader-dict-selection', commandId: 'sireader:dict-selection', variant: 'icon' },
      { type: 'command-button', id: 'sireader-translate-selection', commandId: 'sireader:translate-selection', variant: 'icon' },
      { type: 'command-button', id: 'sireader-speak-selection', commandId: 'sireader:speak-selection', variant: 'icon' }, // CUSTOM: fork
      ...(docs.length ? [
        { type: 'divider', id: 'sireader-send-selection-divider', categories: ['selection', 'sireader-send'] },
        { type: 'command-button', id: 'sireader-send-selection-menu', commandId: 'sireader:send-selection-menu', variant: 'icon-text', categories: ['selection', 'sireader-send'] },
      ] : []),
    ] as any)
  }
  const sendMenu = (type: 'selection' | 'annotation') => ({
    id: `sireader-pdf-send-${type}`,
    items: docs.map((doc: any) => ({ type: 'command', id: 'sireader-send-' + type + '-' + encodeURIComponent(doc.id), commandId: pdfQuickSendCommandId(type, doc.id), categories: [type, 'sireader-send'] })),
    categories: [type, 'sireader-send'],
  })
  const sendMenus = { 'sireader-pdf-send-annotation': sendMenu('annotation'), 'sireader-pdf-send-selection': sendMenu('selection') }
  ui.mergeSchema?.({
    toolbars,
    selectionMenus: schema.selectionMenus,
    menus: documentMenu ? {
      ...schema.menus,
      ...sendMenus,
      document: documentMenu.items?.some((item: any) => item.id === 'sireader-capture-copy') ? documentMenu : {
        ...documentMenu,
        items: [...documentMenu.items, { type: 'command', id: 'sireader-capture-copy', commandId: 'sireader:capture-copy', categories: ['document', 'document-capture'] }],
      },
    } : { ...schema.menus, ...sendMenus },
  })
}
const setupPdfCapture = (registry: PluginRegistry) => {
  cleanupCaptureEvents?.()
  const capture = getCapability<any>(registry, 'capture')?.forDocument(documentId)
  const offArea = capture?.onCaptureArea?.(({ blob }: any) => {
    lastCaptureBlob = blob
    queueCaptureCopyButton()
    if (!copyNextCapture) return
    copyNextCapture = false
    void copyCaptureBlob(blob).catch((error: any) => showMessage(error?.message || props.i18n?.copyFailed || 'Copy failed', 2000, 'error'))
  })
  const offState = capture?.onStateChange?.((state: any) => {
    if (state?.isMarqueeCaptureActive) window.dispatchEvent(new Event('sireader:close-reader-panels'))
  })
  cleanupCaptureEvents = () => { offArea?.(); offState?.() }
}
const setupPdfTooltip = () => {
  cleanupTooltipEvents?.()
  const root = rootRef.value
  if (!root) return
  const onMove = (event: PointerEvent) => {
    if (event.pointerType !== 'mouse') return
    if (!root.contains(event.target as Node | null)) return
    const { clientX: x, clientY: y } = event
    cancelAnimationFrame(pdfTooltipFrame)
    pdfTooltipFrame = requestAnimationFrame(() => {
      const item = pdfAnnotationFromPoint(x, y)
      item ? showPdfTooltip(item, x, y) : hidePdfTooltip()
    })
  }
  root.addEventListener('pointermove', onMove, true)
  root.addEventListener('mouseleave', hidePdfTooltip, true)
  document.addEventListener('pointerdown', hidePdfTooltip, true)
  refreshPdfTooltipAnnotations()
  cleanupTooltipEvents = () => {
    cancelAnimationFrame(pdfTooltipFrame)
    root.removeEventListener('pointermove', onMove, true)
    root.removeEventListener('mouseleave', hidePdfTooltip, true)
    document.removeEventListener('pointerdown', hidePdfTooltip, true)
  }
}

const setupPdfMigration = () => {
  cleanupMigrationEvents?.()
  const onMigration = (event: Event) => {
    const detail = (event as CustomEvent).detail || {}
    if (detail.url && detail.url !== storageKey()) return
    if (detail.phase !== 'progress' && detail.phase !== 'done') return
    showMessage(detail.phase === 'done' ? (props.i18n?.annotationMigrationDone || 'Annotation migration complete') : `${props.i18n?.annotationMigrating || 'Migrating annotations'} ${detail.done || 0}/${detail.total || 0}`, 1200)
  }
  window.addEventListener('sireader:pdf-migration', onMigration as EventListener)
  cleanupMigrationEvents = () => window.removeEventListener('sireader:pdf-migration', onMigration as EventListener)
}

const savePdfZoomLevel = (level: unknown) => {
  const pdfZoomLevel = normalizePdfZoomLevel(level)
  const settings = readerSettings()
  if (!pdfZoomLevel || !settings || settings.pdfZoomLevel === pdfZoomLevel) return
  clearTimeout(zoomSaveTimer)
  zoomSaveTimer = setTimeout(() => {
    zoomSaveTimer = null
    void settingsManager.patch({ pdfZoomLevel })
  }, 400)
}

const handleInit = (container: EmbedPdfContainer) => {
  activeContainer = container
  applyPdfTheme()
}

const handleReady = async (registry: PluginRegistry, nativeLoaded = false) => {
  cleanupPdfShortcutGuard?.()
  cleanupPdfShortcutGuard = installPdfShortcutGuard()
  const sessionToken = viewerToken
  const recordKey = storageKey()
  const bookUrl = pdfBookUrl()
  const isReflowDocument = reflowOpen.value, generated = reflowDocument
  const originalKey = sourceStorageKey(), originalUrl = props.bookUrl
  const syncProjection = async (event: { type: string; annotation: any }) => {
    if (!isReflowDocument || !generated) return
    const id = await synchronizeReflowAnnotation(originalKey, generated, event)
    if (id) generated.projectionIds.add(id)
  }
  let progressReady = nativeLoaded
  const progressSaver = createLatestSaver(async (page: { pageNumber: number; totalPages: number }) => {
    if (!bookUrl) return
    if (isReflowDocument && generated) {
      await writeEmbedPdfProgress(recordKey, { pageNumber: page.pageNumber, totalPages: page.totalPages, updatedAt: Date.now() })
      const source = (generated.pageMap[page.pageNumber - 1] ?? 0) + 1
      if (originalUrl) await bookshelfManager.updateProgress(originalUrl, Math.round(source / generated.sourcePageCount * 100), source, '#page-' + source, { key: originalKey, totalPages: generated.sourcePageCount })
      return
    }
    await bookshelfManager.updateProgress(bookUrl, page.totalPages ? Math.round(page.pageNumber / page.totalPages * 100) : 0, page.pageNumber, `#page-${page.pageNumber}`, { key: recordKey, totalPages: page.totalPages })
  }, 500)
  const queueProgressSave = (page: { pageNumber: number; totalPages: number }) => { if (progressReady) progressSaver.schedule(page) }
  activeRegistry = registry
  nativePdfAnnotationIds = new Set()
  emit('ready', registry, { documentId, bookUrl: pdfBookUrl(), storageKey: recordKey })
  setupPdfMigration()
  ;[cleanupDocumentEvents, cleanupAnnotationEvents, cleanupScrollEvents, cleanupZoomEvents, cleanupPdfDoubleTapZoom].forEach(cleanup => cleanup?.())
  pdfZoomRestore = null
  cleanupDocumentEvents = cleanupAnnotationEvents = cleanupScrollEvents = cleanupZoomEvents = cleanupPdfDoubleTapZoom = null
  const scroll = getCapability<any>(registry, 'scroll')
  const zoom = getCapability<any>(registry, 'zoom')?.forDocument?.(documentId)
  const savedZoomLevel = pdfZoomLevel()
  let pendingSavedZoom = typeof savedZoomLevel === 'number' && !!scroll?.forDocument
  if (scroll?.forDocument) {
    let restored = false
      const progressAliases = bookUrl && bookUrl !== recordKey ? [bookUrl] : []
      const savedProgress = bookUrl ? readEmbedPdfProgress(recordKey, progressAliases) : Promise.resolve(null)
      void savedProgress.catch(error => diagnosticLog('error', 'pdf.progress.read.failed', { key: recordKey, error }))
    const restore = async () => {
      if (restored || !savedProgress) return
      const saved = await savedProgress
      if (sessionToken !== viewerToken) return
      progressReady = true
      if (!saved?.pageNumber) return
      restored = true
      scroll.forDocument(documentId).scrollToPage({
        pageNumber: saved.pageNumber,
        pageCoordinates: saved.pageCoordinates,
        behavior: 'instant',
        alignX: 0,
        alignY: 0,
      })
    }
    const offPage = scroll.onPageChange?.((event: any) => {
      if (event.documentId === documentId) queueProgressSave({ pageNumber: event.pageNumber, totalPages: event.totalPages })
    })
    const offLayout = scroll.onLayoutReady?.((event: any) => {
      if (event.documentId === documentId && event.isInitial && !nativeLoaded) {
        if (pendingSavedZoom) zoom?.requestZoom?.(savedZoomLevel)
        pendingSavedZoom = false
        void restore().catch(error => diagnosticLog('error', 'pdf.progress.restore.failed', { key: recordKey, error }))
      }
    })
    cleanupScrollEvents = () => { offPage?.(); offLayout?.() }
  }
  const documents = getCapability<any>(registry, 'document-manager')
  const getPageHeights = () => (documents?.getDocumentState(documentId)?.document?.pages || []).map((page: any) => Number(page?.size?.height || 0))
  const annotationRoot = getCapability<any>(registry, 'annotation')
  const toolIds = ['ink', 'inkHighlighter', 'line', 'lineArrow', 'polyline', 'polygon', 'square', 'circle'] as const
  const tool = (id: string) => annotationRoot?.getTool?.(id) || annotationRoot?.getTools?.()?.find?.((item: any) => item?.id === id)
  const clone = (value: any) => { try { value = value && typeof value === 'object' && !Array.isArray(value) ? JSON.parse(JSON.stringify(value)) : null } catch { value = null } return value && Object.keys(value).length ? value : null }
  const readToolDefaults = () => toolIds.reduce((next: Record<string, Record<string, any>>, id) => { const value = clone(tool(id)?.defaults); if (value) next[id] = value; return next }, {})
  const applyToolDefaults = (defaults: any) => toolIds.forEach(id => { const value = clone(defaults?.[id]); if (value && tool(id)) annotationRoot?.setToolDefaults?.(id, value) })
  let toolDefaultsTimer: any = null
  let offTools: (() => void) | null = null
  const saveToolDefaults = () => {
    const settings = readerSettings()
    if (!settings) return
    const pdfAnnotationToolDefaults = readToolDefaults()
    if (JSON.stringify(settings.pdfAnnotationToolDefaults || {}) === JSON.stringify(pdfAnnotationToolDefaults || {})) return
    void settingsManager.patch({ pdfAnnotationToolDefaults })
  }
  if (annotationRoot) {
    applyToolDefaults(readerSettings()?.pdfAnnotationToolDefaults)
    offTools = annotationRoot.onToolsChange?.(() => {
      clearTimeout(toolDefaultsTimer)
      toolDefaultsTimer = setTimeout(() => {
        toolDefaultsTimer = null
        saveToolDefaults()
      }, 400)
    })
  }
  activeAnnotationScope = annotationRoot?.forDocument(documentId) || null
  activeScrollScope = scroll?.forDocument?.(documentId) || null
  const offZoomState = zoom?.onStateChange?.((state: any) => {
    if (pendingSavedZoom && typeof state?.zoomLevel !== 'number') return
    savePdfZoomLevel(state?.zoomLevel)
  })
  cleanupZoomEvents = () => offZoomState?.()
  const ui = getCapability<any>(registry, 'ui'), sidebarPanel = ui?.getSchema?.().sidebars?.['sidebar-panel'] as any, tabs = sidebarPanel?.content?.tabs
  const outline = Array.isArray(tabs) ? tabs.find((tab: any) => tab.id === 'outline') : null
  if (outline && tabs[0]?.id !== 'outline') ui?.mergeSchema?.({ sidebars: { 'sidebar-panel': { ...sidebarPanel, content: { ...sidebarPanel.content, tabs: [outline, ...tabs.filter((tab: any) => tab.id !== 'outline')] } } } as any })
  setupPdfCommands(registry)
  setupPdfBottomButtons(registry)
  setupPdfDoubleTapZoom(registry)
  setupPdfCapture(registry)
  let annotationsLoaded = false
  let annotationPersistenceReady = false
  const storedAnnotationIds = new Set<string>()
  const restoringIds = new Set<string>()
  const annotation = activeAnnotationScope
  // Vue removes custom elements synchronously. Capture pending user mutations
  // before the engine is destroyed; storage completion must not depend on it.
  const pendingAnnotations = new Map<string, any>()
  savePendingAnnotations = () => {
    const pending = [...pendingAnnotations.values()]
    pendingAnnotations.clear()
    if (!pending.length) return
    annotationPersistenceQueue = annotationPersistenceQueue.catch(() => undefined).then(async () => {
      for (const event of pending) {
        if (event.type === 'delete') await deleteEmbedPdfAnnotation(recordKey, event.annotation.id)
        else await upsertEmbedPdfAnnotation(recordKey, { annotation: event.annotation, ...(event.ctx ? { ctx: event.ctx } : {}) })
        await syncProjection(event)
      }
      diagnosticLog('info', 'pdf.annotations.saved-on-close', { key: recordKey, count: pending.length })
    })
    trackPending(annotationPersistenceQueue).catch(error => diagnosticLog('error', 'pdf.annotations.close.failed', { key: recordKey, error }))
  }
  const annotationIds = () => new Set(annotation?.getAnnotations?.()?.map((item: any) => item.object?.id).filter(Boolean) || [])
  const loadAnnotations = async () => {
    if (annotationsLoaded) return
    annotationsLoaded = true
    const startedAt = Date.now()
    if (!recordKey || !annotation?.importAnnotations) {
      annotationPersistenceReady = true
      emit('annotations-ready')
      window.dispatchEvent(new Event('sireader:marks-updated'))
      refreshPdfTooltipAnnotations()
      return
    }
    const existingNativeIds = annotationIds()
    const pageHeights = getPageHeights()
    const legacyKey = bookUrl && bookUrl !== recordKey ? [bookUrl] : []
    const stored = await readEmbedPdfAnnotations(recordKey, pageHeights, legacyKey)
    if (sessionToken !== viewerToken) return
    if (isReflowDocument && generated && !generated.annotationsBridged) {
      for (const item of stored || []) await syncProjection({ type: 'create', annotation: item.annotation || item })
      generated.annotationsBridged = true
    }
    // Cached source bytes may contain an earlier projection. The source record is authoritative.
    if (!isReflowDocument && generated?.projectionIds.size) {
      for (const item of annotation.getAnnotations?.() || []) {
        const a = item.object
        if (!generated.projectionIds.has(a?.id)) continue
        await taskToPromise(annotation.deleteAnnotation(a.pageIndex, a.id))
        existingNativeIds.delete(a.id)
      }
      await taskToPromise(annotation.commit?.())
    }
    stored?.forEach((item: any) => storedAnnotationIds.add((item.annotation || item)?.id))
    nativePdfAnnotationIds = new Set([...existingNativeIds].filter(id => !storedAnnotationIds.has(id)))
    const managed = stored?.filter((item: any) => !existingNativeIds.has((item.annotation || item)?.id)) || []
    const aligned = managed.length && needsLegacyPdfTextAlign(managed) ? await alignLegacyPdfAnnotations(managed, registry, documents, documentId) : managed
    // Loading a subset into the viewer must never replace the complete record.
    if (aligned !== managed) for (const item of aligned) await upsertEmbedPdfAnnotation(recordKey, item)
    if (managed.length) {
      aligned.forEach(item => restoringIds.add(item.annotation.id))
      annotation.importAnnotations(aligned)
      // 2.15.x exposes an explicit commit task.  Keep the PDF engine state
      // and the SiReader record in sync before announcing readiness.
      await taskToPromise(annotation.commit?.())
      await new Promise<void>(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)))
      restoringIds.clear()
    }
    if (sessionToken !== viewerToken) return
    diagnosticLog('info', 'pdf.annotations.loaded', { key: recordKey, stored: stored?.length || 0, native: nativePdfAnnotationIds.size, managed: managed.length, created: managed.filter((item: any) => !existingNativeIds.has((item.annotation || item)?.id)).length, durationMs: Date.now() - startedAt })
    annotationPersistenceReady = true
    emit('annotations-ready')
    window.dispatchEvent(new Event('sireader:marks-updated'))
    refreshPdfTooltipAnnotations()
  }
  if (annotation) {
    const offActiveTool = annotation.onActiveToolChange?.((tool: any) => {
      if (tool?.id) lastPdfAnnotationToolId = tool.id

    })
    const offEvent = annotation.onAnnotationEvent?.((event: any) => {
      const id = event?.annotation?.id
      if (event.committed && id && restoringIds.delete(id)) return
      if (event.committed === false && annotationPersistenceReady) {
        if (id && !nativePdfAnnotationIds.has(id)) {
          const previous = pendingAnnotations.get(id)
          pendingAnnotations.set(id, snapshotPdfAnnotationEvent(event, previous))
        }
        annotationCommitQueue = annotationCommitQueue.catch(() => undefined).then(async () => { await taskToPromise(annotation.commit()) })
        trackPending(annotationCommitQueue).catch(error => {
          diagnosticLog('error', 'pdf.annotation.commit.failed', { key: recordKey, id, error })
          showMessage(props.i18n?.pdfAnnotationCommitFailed || 'Failed to commit PDF annotations. Export diagnostic logs for details.', 5000, 'error')
        })
      }
      const activeToolId = event?.type === 'create' && pdfAnnotationToolLocked ? lastPdfAnnotationToolId : null
      if (event?.type === 'loaded') {
        nativePdfAnnotationIds = new Set([...annotationIds()].filter(id => !storedAnnotationIds.has(id)))
        void loadAnnotations().catch(error => {
          diagnosticLog('error', 'pdf.annotations.load.failed', { key: recordKey, error })
          showMessage(props.i18n?.pdfAnnotationReadFailed || 'Failed to read PDF annotations. Existing records were preserved. Export diagnostic logs for details.', 5000, 'error')
        })
      } else if (annotationPersistenceReady && event.committed === true && ['create', 'update', 'delete'].includes(event?.type) && id && !nativePdfAnnotationIds.has(id)) {
        const snapshot = cloneStorageValue(event.annotation)
        const persistedEvent = {
          type: event.type,
          annotation: snapshot,
        }
        const onCommit = () => props.onAnnotationPersisted?.({ ...persistedEvent, bookUrl, storageKey: recordKey })
        const key = recordKey
        const context = event.ctx && cloneStorageValue(event.ctx)
        // Engine commit is not durable storage. Retain the mutation until the
        // file write succeeds, without removing a newer edit of the same ID.
        const waiting = pendingAnnotations.get(id)
        const pendingSave = waiting && waiting.type === event.type && JSON.stringify(waiting.annotation) === JSON.stringify(snapshot)
          ? waiting : { type: event.type, annotation: snapshot, ...(context ? { ctx: context } : {}) }
        if (!waiting) pendingAnnotations.set(id, pendingSave)
        const transferTask = snapshot.type === 13 && event.type !== 'delete'
          ? taskToPromise<any[]>(annotation.exportAnnotations({ pageIndex: snapshot.pageIndex }))
          : Promise.resolve(null)
        void transferTask.catch(error => diagnosticLog('error', 'pdf.annotation.export.failed', { key, id, error }))
        annotationPersistenceQueue = annotationPersistenceQueue.catch(() => undefined).then(async () => {
          if (event.type === 'delete') await deleteEmbedPdfAnnotation(key, id, onCommit)
          else {
            const transfer = (await transferTask)?.find(item => item.annotation.id === id)
            await upsertEmbedPdfAnnotation(key, transfer || { annotation: snapshot, ...(context ? { ctx: context } : {}) }, onCommit)
          }
          await syncProjection(persistedEvent)
          if (pendingAnnotations.get(id) === pendingSave) pendingAnnotations.delete(id)
          window.dispatchEvent(new Event('sireader:marks-updated'))
        })
        trackPending(annotationPersistenceQueue).catch(error => {
          diagnosticLog('error', 'pdf.annotation.save.failed', { key, id, error })
          showMessage(props.i18n?.pdfAnnotationSaveFailed || 'Failed to save PDF annotations. Export diagnostic logs for details.', 5000, 'error')
        })
      }
      if (activeToolId) restorePdfAnnotationTool(annotation, activeToolId)
      refreshPdfTooltipAnnotations()
    })
    const offState = annotation.onStateChange?.(refreshPdfTooltipAnnotations)
    cleanupAnnotationEvents = () => {
      clearTimeout(toolDefaultsTimer)
      offActiveTool?.()
      offEvent?.()
      offState?.()
      offTools?.()
      if (toolDefaultsTimer) saveToolDefaults()
    }
  }
  const offError = documents?.onDocumentError?.((event: any) => {
    if (event.documentId === documentId) showMessage(event.message || pdfLoadFailedMessage(), 3000, 'error')
  })
  cleanupDocumentEvents = () => offError?.()
  const previousCleanupScrollEvents = cleanupScrollEvents
  cleanupScrollEvents = () => { previousCleanupScrollEvents?.(); void trackPending(progressSaver.flush()).catch(error => diagnosticLog('error', 'pdf.progress.flush.failed', { key: recordKey, error })) }
  if (nativeLoaded) await loadAnnotations()
  diagnosticLog('info', 'pdf.ready', { key: recordKey, documentId })
  ensurePageThemeStyle()
  void nextTick(setupPdfTooltip)
}

let sourceToken = 0
watch(() => props.source, async (source) => {
  const token = ++sourceToken
  disposePdfViewer()
  documentSource.value = null
  pdfLoadError.value = ''
  pdfPreparing.value = source ? pdfLoadingText() : ''
  if (!source) return
  try {
    await preparePdfAssets()
    const nextSource = await createEmbedPdfDocumentSource(documentId, source)
    if (token === sourceToken) documentSource.value = nextSource
  } catch (error: any) {
    if (token === sourceToken) failPdfLoad(error)
  }
}, { immediate: true })

const config = computed(() => ({
  tabBar: 'never',
  worker: true,
  wasmUrl: pdfAssets.value?.wasmUrl,
  documentManager: {
    initialDocuments: [documentSource.value],
  },
  scroll: { defaultStrategy: getPdfScrollStrategy(props.settings?.pdfScrollDirection) },
  fonts: { ui: null, signature: null },
  stamp: { manifests: pdfAssets.value?.stampManifests || [] },
  permissions: { enforceDocumentPermissions: true },
  capture: { imageType: 'image/png', scale: 2, withAnnotations: true },
  annotations: { autoCommit: false, annotationAuthor: 'SiReader', deactivateToolAfterCreate: true },
  pan: { defaultMode: 'always' },
  commands: {
    'scroll:previous-page': { id: 'scroll:previous-page', labelKey: 'page.previous', icon: 'chevronLeft', categories: ['page', 'navigation', 'navigation-previous'], action: ({ registry, documentId }: any) => registry.getPlugin('scroll')?.provides()?.forDocument(documentId)?.scrollToPreviousPage(pdfPageBehavior()) },
    'scroll:next-page': { id: 'scroll:next-page', labelKey: 'page.next', icon: 'chevronRight', categories: ['page', 'navigation', 'navigation-next'], action: ({ registry, documentId }: any) => registry.getPlugin('scroll')?.provides()?.forDocument(documentId)?.scrollToNextPage(pdfPageBehavior()) },
  },
  zoom: { defaultZoomLevel: pdfInitialZoomLevel() ?? 'fit-width' },
  redaction: { useAnnotationMode: true, drawBlackBoxes: true },
  i18n: {
    defaultLocale: embedPdfLocale((window as any).siyuan?.config?.lang || '', props.i18n?.name),
    fallbackLocale: 'en',
  },
  theme: pdfTheme(),
}))

const waitForRegistry = (viewer: any, timeout = 15000) => new Promise<PluginRegistry>((resolve, reject) => {
  const timer = setTimeout(() => reject(new Error('PDF engine initialization timed out')), timeout)
  viewer.registry.then((registry: PluginRegistry) => { clearTimeout(timer); resolve(registry) }, (error: any) => { clearTimeout(timer); reject(error) })
})

const mountPdfViewer = async () => {
  const host = viewerHostRef.value
  if (!host || !documentSource.value || !pdfAssets.value || activeViewer) return
  const token = ++viewerToken
  let viewer: any
  try {
    const start = async (worker: boolean) => {
      host.replaceChildren()
      viewer = await initEmbedPdfViewer(host, { ...config.value, worker })
      if (!viewer) throw new Error(pdfLoadFailedMessage())
      return waitForRegistry(viewer)
    }
    let registry: PluginRegistry
    try {
      registry = await start(true)
    } catch {
      viewer?.remove?.()
      if (token !== viewerToken) return
      registry = await start(false)
    }
    if (token !== viewerToken || viewerHostRef.value !== host) return void viewer?.remove?.()
    activeViewer = viewer
    setupPdfNavigation(registry)
    handleInit(activeViewer)
    pdfPreparing.value = ''
    void handleReady(registry).catch(error => failPdfLoad(error))
  } catch (error: any) {
    viewer?.remove?.()
    if (token === viewerToken) failPdfLoad(error)
  }
}

watch(() => [documentSource.value, pdfAssets.value, viewerHostRef.value], () => nextTick(mountPdfViewer), { flush: 'post' })
watch(() => [props.theme, props.customTheme?.color, props.customTheme?.bg, props.settings?.backgroundImage], () => nextTick(applyPdfTheme))
watch(() => props.settings?.pdfScrollDirection, direction => activeScrollScope?.setScrollStrategy?.(getPdfScrollStrategy(direction)))
watch(() => props.hideAnnotations, hidden => syncPdfAnnotationsHidden(!!hidden))
watch(() => props.settings?.quickSendDocs, () => activeRegistry && setupPdfCommands(activeRegistry), { deep: true })
const themeObserver = new MutationObserver(() => requestAnimationFrame(applyPdfTheme))
;[document.documentElement, document.body].forEach(el => themeObserver.observe(el, { attributes: true, attributeFilter: ['class', 'style', 'data-theme-mode'] }))

onBeforeUnmount(() => {
  clearTimeout(zoomSaveTimer)
  cleanupAnnotationEvents?.()
  cleanupDocumentEvents?.()
  cleanupScrollEvents?.()
  cleanupZoomEvents?.()
  cleanupCaptureEvents?.()
  cleanupTooltipEvents?.()
  cleanupMigrationEvents?.()
  cleanupPdfDoubleTapZoom?.()
  disposePdfCommands(activeRegistry && getCapability<any>(activeRegistry, 'commands'))
  pdfZoomRestore = null
  themeObserver.disconnect()
  activeAnnotationScope = null
  activeScrollScope = null
  activeContainer = null
  nativePdfAnnotationIds = new Set()
  disposePdfViewer()
  pdfTooltip?.remove()
  pdfTooltip = null
})

const resize = () => {
  const container = rootRef.value?.querySelector('embedpdf-container') as HTMLElement | null
  const shadow = container?.shadowRoot
  const appRoot = shadow?.querySelector('.bg-bg-app') as HTMLElement | null
  if (appRoot && !appRoot.children.length && activeViewer) {
    disposePdfViewer()
    void nextTick(mountPdfViewer)
  }
}

const flushAnnotations = async () => {
  await annotationCommitQueue
  await taskToPromise(activeAnnotationScope?.commit?.())
  await annotationPersistenceQueue
}
defineExpose({ resize, flushAnnotations })
</script>

<style scoped>
.embed-pdf-reader{position:relative;width:100%;height:100%;display:block;background:var(--b3-theme-background)}
.embed-pdf-reader :deep(> *){width:100%;height:100%}
.embed-pdf-reader__loading{height:100%;display:flex;align-items:center;justify-content:center;color:var(--b3-theme-on-surface)}
.embed-pdf-reader__loading--overlay{position:absolute;inset:0;background:var(--b3-theme-background);z-index:1}
</style>
